import React from 'react';
import Title from './comps/Title';

function App() {
  return (
    <div className="App">
      <Title/>
    </div>
  );
}

export default App;
